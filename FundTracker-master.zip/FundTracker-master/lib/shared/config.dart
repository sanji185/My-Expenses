import 'package:fund_tracker/shared/constants.dart';

const DatabaseType DATABASE_TYPE = DatabaseType.Local;

const String LOCAL_DATABASE_FILENAME = 'v2';

const int NUM_PERIODIC_STAT_PERIODS = 6;