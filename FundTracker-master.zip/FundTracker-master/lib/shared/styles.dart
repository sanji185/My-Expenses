import 'package:flutter/material.dart';

EdgeInsets formPadding = EdgeInsets.symmetric(
  vertical: 20.0,
  horizontal: 50.0,
);

EdgeInsets bodyPadding = EdgeInsets.symmetric(
  vertical: 20.0,
  horizontal: 10.0,
);
